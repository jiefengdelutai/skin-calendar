#!/usr/bin/env python3
"""
Skincare Plan Validator
Validates structured skincare plan JSON payloads against:
1. Schema completeness (plan_meta, product_inventory, schedule)
2. Product ID referential integrity (every scheduled step references a valid product_id)
3. Slot compatibility (products are only used in their allowed_slots)
4. Hard active-ingredient conflict guardrails within the same AM/PM session
   and consecutive-night active stacking warnings.
"""

import json
import sys
from pathlib import Path

CONFLICT_RULES = [
    (
        {"retinoid", "retinol", "retinal", "tretinoin", "adapalene"},
        {"aha", "bha", "pha", "glycolic", "salicylic", "lactic", "mandelic", "exfoliant", "scrub"},
        "CRITICAL CONFLICT: Retinoid and chemical/physical exfoliant stacked in the same session."
    ),
    (
        {"retinoid", "retinol", "retinal", "tretinoin", "adapalene"},
        {"benzoyl peroxide", "bpo"},
        "CRITICAL CONFLICT: Benzoyl Peroxide oxidizes retinoids and causes severe irritation."
    ),
    (
        {"retinoid", "retinol", "retinal", "tretinoin", "adapalene"},
        {"l-ascorbic acid", "pure vitamin c", "ascorbic acid"},
        "WARNING: Pure L-Ascorbic Acid and Retinoid in the same session; split AM/PM."
    ),
    (
        {"copper peptide", "ghk-cu"},
        {"aha", "bha", "pha", "glycolic", "salicylic", "l-ascorbic acid", "ascorbic acid"},
        "CRITICAL CONFLICT: Low-pH acids or pure Vitamin C destabilize Copper Peptides."
    ),
    (
        {"benzoyl peroxide", "bpo"},
        {"l-ascorbic acid", "pure vitamin c", "ascorbic acid"},
        "CRITICAL CONFLICT: Benzoyl Peroxide oxidizes Vitamin C."
    ),
]

EXFOLIANT_KEYWORDS = {"aha", "bha", "pha", "glycolic", "salicylic", "lactic", "mandelic", "exfoliant", "scrub"}
RETINOID_KEYWORDS = {"retinoid", "retinol", "retinal", "tretinoin", "adapalene"}


def normalize_tokens(product: dict) -> set[str]:
    tokens = set()
    cat = str(product.get("category", "")).lower().strip()
    if cat:
        tokens.add(cat)
    for act in product.get("key_actives", []):
        act_lower = str(act).lower().strip()
        tokens.add(act_lower)
        for kw in EXFOLIANT_KEYWORDS | RETINOID_KEYWORDS | {
            "benzoyl peroxide", "bpo", "l-ascorbic acid", "pure vitamin c",
            "ascorbic acid", "copper peptide", "ghk-cu"
        }:
            if kw in act_lower:
                tokens.add(kw)
    return tokens


def validate_plan(plan: dict) -> dict:
    errors = []
    warnings = []

    for top_key in ("plan_meta", "product_inventory", "schedule"):
        if top_key not in plan:
            errors.append(f"Missing required top-level field: '{top_key}'")

    if errors:
        return {"valid": False, "errors": errors, "warnings": warnings}

    inventory = {}
    for idx, item in enumerate(plan.get("product_inventory", [])):
        pid = item.get("id")
        if not pid:
            errors.append(f"Product at index {idx} is missing 'id'")
            continue
        if pid in inventory:
            errors.append(f"Duplicate product_id '{pid}' in product_inventory")
        inventory[pid] = {
            "raw": item,
            "tokens": normalize_tokens(item),
            "allowed_slots": set(item.get("allowed_slots", [])),
        }

    prev_pm_had_potent_active = False

    for day in plan.get("schedule", []):
        day_label = f"Day {day.get('day_index', '?')} ({day.get('date', 'no-date')})"

        for period in ("am", "pm"):
            steps = day.get(period, [])
            if not isinstance(steps, list) or not steps:
                warnings.append(f"{day_label} [{period.upper()}]: Empty routine step list.")
                continue

            session_tokens = set()
            exfoliant_count = 0

            for step in steps:
                pid = step.get("product_id")
                if pid not in inventory:
                    errors.append(f"{day_label} [{period.upper()}]: Unknown product_id '{pid}'")
                    continue

                prod_info = inventory[pid]
                allowed = prod_info["allowed_slots"]
                if allowed:
                    if period == "am" and "AM" not in allowed:
                        warnings.append(f"{day_label} [AM]: Product '{pid}' not marked for AM slot.")
                    if period == "pm" and not ({"PM", "PM_ACTIVE", "PM_RECOVERY"} & allowed):
                        warnings.append(f"{day_label} [PM]: Product '{pid}' not marked for PM slot.")

                ptokens = prod_info["tokens"]
                if ptokens & EXFOLIANT_KEYWORDS:
                    exfoliant_count += 1
                session_tokens |= ptokens

            if exfoliant_count > 1:
                errors.append(
                    f"{day_label} [{period.upper()}]: Multiple exfoliants ({exfoliant_count}) stacked in one session."
                )

            for group_a, group_b, msg in CONFLICT_RULES:
                if (session_tokens & group_a) and (session_tokens & group_b):
                    errors.append(f"{day_label} [{period.upper()}]: {msg}")

            if period == "pm":
                has_potent = bool(session_tokens & (EXFOLIANT_KEYWORDS | RETINOID_KEYWORDS))
                if has_potent and prev_pm_had_potent_active:
                    warnings.append(
                        f"{day_label} [PM]: Potent actives scheduled on consecutive nights without a recovery night."
                    )
                prev_pm_had_potent_active = has_potent

    return {
        "valid": len(errors) == 0,
        "errors": errors,
        "warnings": warnings,
    }


def main():
    if len(sys.argv) < 2:
        print("Usage: python validate_plan.py <path_to_plan.json>")
        sys.exit(1)

    path = Path(sys.argv[1])
    if not path.exists():
        print(f"File not found: {path}")
        sys.exit(1)

    data = json.loads(path.read_text(encoding="utf-8"))
    result = validate_plan(data)
    print(json.dumps(result, ensure_ascii=False, indent=2))
    sys.exit(0 if result["valid"] else 1)


if __name__ == "__main__":
    main()
