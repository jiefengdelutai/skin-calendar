# Phased Routine Templates and Calendar Schema

Use these templates to build progressive skincare plans rather than static daily routines.

## 1. Phased Progression Framework

### Phase 0: SOS Barrier Repair (7 to 14 Days)

- **Target State:** Compromised barrier, stinging, redness, peeling, or post-aesthetic procedure.
- **Rule:** Zero exfoliating acids, zero retinoids, zero pure L-ascorbic acid, zero clay masks or scrubs.
- **AM:** Water rinse or ultra-gentle non-foaming cleanser -> Panthenol/Centella/Ectoin soothing serum -> Ceramide barrier cream -> Gentle mineral or sensitive-skin SPF.
- **PM:** Gentle cleanser -> Hydrating serum (Hyaluronic acid / Beta-glucan) -> Ceramide + Cholesterol + Fatty Acid moisturizer -> Optional squalane seal on flaky areas.
- **Exit Criteria:** Skin feels comfortable all day, zero stinging when applying moisturizer for 5 consecutive days.

### Phase 1: Tolerance Ramp-Up (Weeks 2 to 4)

- **Target State:** Recovered barrier, introducing or re-introducing one primary active.
- **Schedule (7-Day Week):**
  - **Mon:** Primary Active (e.g., Low-dose Retinoid, buffered with moisturizer)
  - **Tue:** Recovery
  - **Wed:** Recovery
  - **Thu:** Primary Active (or gentle PHA/Mandelic acid if exfoliation-focused)
  - **Fri:** Recovery
  - **Sat:** Recovery
  - **Sun:** Recovery

### Phase 2: Customized Skin Cycling (Weeks 4 to 12)

Select cycle length based on skin tolerance and climate:

- **Standard 4-Night Cycle (Normal / Combination / Resilient Skin):**
  - **Night 1 (Exfoliation):** Single AHA (glycolic/lactic) or BHA (salicylic) -> Hydrating serum -> Moisturizer.
  - **Night 2 (Retinoid):** Retinol / Retinal / Adapalene -> Soothing serum -> Moisturizer.
  - **Night 3 (Recovery):** Gentle cleanse -> Hydrating serum -> Ceramide barrier moisturizer.
  - **Night 4 (Recovery):** Gentle cleanse -> Hydrating serum -> Ceramide barrier moisturizer.
- **Extended 5-Night or 6-Night Cycle (Sensitive / Dry / Cold-Dry Climate):**
  - Insert 3 to 4 Recovery Nights after Night 2 Retinoid (or drop Night 1 Exfoliation completely if skin reddens easily).

### Phase 3: Long-Term Maintenance and Climate Adaptation

- **High Heat and Humidity (e.g., Tropical / Summer):**
  - Switch heavy occlusive creams in AM to oil-free gel-creams or fluid emulsions.
  - Prioritize BHA (salicylic acid) or Azelaic acid for sebum and pore congestion control.
  - Use water-resistant, lightweight fluid SPF.
- **Cold and Low Humidity (e.g., Winter / Air-Conditioned Rooms):**
  - Reduce exfoliation frequency by 50%.
  - Add an extra recovery night per cycle and layer squalane or richer ceramide creams at night.

## 2. Structured Calendar JSON Schema (For Web App / Mini-Tool Integration)

When generating a machine-readable plan for calendar UI rendering (`PlanCalendar` / `skin-calendar`), output a JSON block conforming to this structure:

```json
{
  "plan_meta": {
    "title": "Phased Barrier Repair & Skin Cycling Plan",
    "start_date": "YYYY-MM-DD",
    "cycle_length_days": 4,
    "current_phase": "Phase 2 - Skin Cycling",
    "skin_profile": {
      "type": "Combination / Sensitive",
      "primary_goals": ["Barrier stability", "Texture refinement"],
      "climate": "Humid tropical"
    }
  },
  "product_inventory": [
    {
      "id": "p1",
      "name": "Exact Product Name",
      "category": "Cleanser | Toner | Antioxidant | Exfoliant | Retinoid | Soothing | Moisturizer | Sunscreen",
      "key_actives": ["Ingredient 1"],
      "allowed_slots": ["AM", "PM_ACTIVE", "PM_RECOVERY"]
    }
  ],
  "schedule": [
    {
      "day_index": 1,
      "date": "YYYY-MM-DD",
      "cycle_tag": "Exfoliation Night",
      "am": [
        { "step": 1, "product_id": "p1", "note": "Gentle cleanse" }
      ],
      "pm": [
        { "step": 1, "product_id": "p1", "note": "Double cleanse if SPF worn" }
      ],
      "watch_out": "Skip exfoliant if any stinging occurs; convert to Recovery Night."
    }
  ]
}
```
