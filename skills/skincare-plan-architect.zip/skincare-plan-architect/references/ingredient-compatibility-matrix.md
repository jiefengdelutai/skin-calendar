# Active Ingredient Compatibility and Layering Matrix

Use this reference when auditing product combinations, resolving conflicts, and ordering AM/PM skincare steps.

## 1. Ingredient Pairing Matrix

| Pairing | Verdict | Mechanism and Execution Rule |
| :--- | :--- | :--- |
| **Retinoid + Niacinamide** | Synergistic | Niacinamide boosts ceramide synthesis and reduces retinoid-induced irritation. Apply niacinamide before or buffered with retinoid. |
| **Retinoid + Peptides (non-copper)** | Compatible | Hydrating and signal peptides calm skin and support barrier repair alongside retinoids. |
| **Retinoid + Ceramides / Panthenol / Ectoin** | Essential | Always pair barrier-supporting humectants and lipids on retinoid nights to prevent transepidermal water loss. |
| **Retinoid + AHA / BHA** | Separate Nights | Cumulative irritation and barrier disruption risk. Alternate nights with at least 1-2 recovery nights between them. |
| **Retinoid + Pure Vitamin C (L-Ascorbic Acid)** | Split AM / PM | Optimal pH windows differ and stacking increases irritation. Use Vitamin C in AM and Retinoid in PM. |
| **Retinoid + Benzoyl Peroxide** | Do Not Mix | Benzoyl peroxide oxidizes and deactivates traditional tretinoin/retinol and causes severe dryness. Use BPO in AM (short-contact wash) or separate days. |
| **Vitamin C + Vitamin E + Ferulic Acid** | Synergistic | Classic antioxidant network that stabilizes L-Ascorbic Acid and enhances photoprotection under sunscreen. |
| **Vitamin C + Sunscreen** | Highly Recommended | Antioxidants neutralize free radicals that pass through UV filters. Always layer Vitamin C beneath morning SPF. |
| **Vitamin C + Niacinamide** | Compatible | Stable in modern formulations. If flushing occurs with high-concentration pure L-Ascorbic acid, separate by 10 minutes or split AM/PM. |
| **Copper Peptides (GHK-Cu) + Low-pH Acids / Pure Vit C** | Separate | Low pH can destabilize copper peptide complexes. Use Copper Peptides on recovery nights or separate from acids/L-AA. |
| **AHA + BHA (or Acid + Scrub)** | Pick One Only | Stacking multiple exfoliants is the top cause of over-exfoliation and barrier breakdown. Limit to one exfoliant per session. |
| **Azelaic Acid + Niacinamide / Hyaluronic Acid** | Compatible | Well-tolerated anti-inflammatory and brightening combination suitable for acne-prone or rosacea-prone skin. |

## 2. Standard Layering Order (Thin to Thick / Low pH to High pH)

### Morning (AM) Routine Order

1. **Cleanser:** Gentle amino-acid or non-foaming cleanser (lukewarm water rinse only if dry or sensitized).
2. **Hydrating Toner / Essence (Optional):** Alcohol-free humectant base.
3. **Antioxidant / Brightening Serum:** Pure Vitamin C (on dry skin), Vitamin C derivative, or Niacinamide.
4. **Hydrating / Soothing Serum (Optional):** Hyaluronic acid, panthenol, or centella if extra hydration is needed.
5. **Moisturizer:** Lightweight gel-cream (oily/humid climate) or barrier emulsion/cream (dry skin).
6. **Broad-Spectrum Sunscreen (Mandatory):** SPF 30-50+, PA+++/++++, applied 15 minutes before sun exposure.

### Evening (PM) Routine Order

1. **First Cleanse (if wearing makeup or water-resistant SPF):** Cleansing oil, balm, or micellar water.
2. **Second Cleanse:** Gentle pH-balanced cleanser (5.0-6.0). Pat dry.
3. **Active Step (Active Nights Only):**
   - *Exfoliation Night:* Single AHA, BHA, or PHA toner/serum on dry skin.
   - *Retinoid Night:* Pea-sized amount of Retinol, Retinal, Adapalene, or Tretinoin on completely dry skin. (For sensitive skin, apply a thin layer of basic moisturizer first as a buffer).
4. **Soothing / Hydrating Serum:** Panthenol, beta-glucan, ectoin, or niacinamide.
5. **Barrier Moisturizer:** Cream containing ceramides, cholesterol, fatty acids, or squalane.
6. **Occlusive Seal (Optional, Dry Skin / Recovery Nights):** 2-3 drops of squalane or barrier balm on dry zones.

## 3. Purging vs. Irritation Triage

| Dimension | Normal Retinoid / Acid Purging | Barrier Irritation / Allergic Reaction |
| :--- | :--- | :--- |
| **Location** | Only in areas where you normally get clogged pores or breakouts. | Appears in new, unusual areas (cheeks, temples, around mouth/eyes). |
| **Symptoms** | Small whiteheads, blackheads, or surface pimples coming to a head faster. | Stinging when applying plain moisturizer/water, diffuse redness, tightness, flaking, burning, or itchy bumps. |
| **Timeline** | Peaks around weeks 2-3 and clears within 4-6 weeks. | Worsens with every active application until actives are paused. |
| **Action** | Maintain current schedule; do not squeeze or add extra spot acids. | Immediately drop all actives, switch to Phase 0 Barrier Repair for 7-14 days, then reintroduce at lower frequency. |
