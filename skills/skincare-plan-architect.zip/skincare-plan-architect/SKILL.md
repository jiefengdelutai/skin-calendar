---
name: skincare-plan-architect
description: Design, audit, and optimize personalized, science-backed skincare routines, phased skin recovery schedules, and long-term maintenance calendars. Use whenever the user asks to generate or improve a skincare plan, resolve active ingredient conflicts, build a skin cycling schedule, adjust a routine based on skin reaction logs, or refine AI prompts and structured outputs for skincare calendar apps and mini-tools.
---

# Skincare Plan Architect

Generate precision, executable skincare plans that eliminate generic AI fluff, prevent active ingredient overload, and adapt dynamically to skin barrier status, existing inventory, climate, and historical skin logs.

## Why Generic AI Skincare Plans Fail (And How to Fix Them)

Most AI-generated skincare plans fail for four concrete reasons:

1. **Ingredient stacking and barrier damage:** Recommending acids, retinoids, and high-strength vitamin C simultaneously without buffering or recovery nights.
2. **Product amnesia:** Ignoring what the user already owns or inventing generic placeholders instead of mapping exact owned products to specific AM/PM slots.
3. **Static schedules:** Treating day 1 and day 30 identically instead of structuring phased progression (barrier stabilization -> tolerance building -> active cycling -> maintenance).
4. **Unactionable formatting:** Outputting walls of prose instead of a clear day-by-day execution calendar and concise layering order.

## When to Use

- Creating a new phased skincare plan (barrier repair, acne/texture control, anti-aging, brightening, or post-procedure recovery).
- Auditing or upgrading an existing skincare plan or AI prompt template (`prompt.txt`, `PromptForm`).
- Adjusting an ongoing schedule based on user skin reaction logs (`护理效果记录`) such as stinging, flaking, redness, or purging.
- Converting a skincare strategy into a structured multi-day calendar format for web or mini-tool rendering (`PlanCalendar`).

## Workflow

### Step 1: Audit Context and Inventory

Before drafting any routine, extract and lock down four inputs from the user's message, attached files, or prior logs:

1. **Current Skin State and Primary Goal:** Separate immediate barrier status (intact, sensitized, stinging, peeling, post-treatment) from long-term goals (acne, hyperpigmentation, texture, fine lines). Barrier repair always overrides cosmetic actives when compromised.
2. **Existing Product Inventory:** List every product the user already has, identifying its core active ingredients, concentration/form, and texture (watery toner, essence, gel, emulsion, cream, oil, sunscreen). Prioritize scheduling owned products before suggesting additions.
3. **Environment and Constraints:** Account for local climate (high heat/humidity vs. dry/cold), UV exposure, budget, time budget (minimalist vs. multi-step), and explicit dislikes.
4. **Historical Feedback Logs:** If the user provides reaction records (`护理效果记录`), identify which specific product or pairing triggered irritation or delivered improvement, and adjust frequency accordingly.

If critical information (such as current skin sensitivity or owned products) is completely missing, ask 2 to 3 targeted, concrete questions first. If the user provides a draft plan or inventory, proceed directly to generation.

### Step 2: Enforce Formulation and Compatibility Guardrails

Consult `references/ingredient-compatibility-matrix.md` to verify every AM and PM combination before finalizing the schedule:

- **AM = Protection and Antioxidants:** Pair gentle cleansing (or water rinse for dry/sensitized skin) with antioxidants (Vitamin C, Niacinamide, Ferulic Acid), lightweight hydration, and broad-spectrum SPF 30-50+.
- **PM = Repair and Cell Turnover:** Separate potent actives across nights rather than layering them in one session.
- **Hard Conflict Prevention:**
  - Never stack two chemical exfoliants (AHA, BHA, PHA, physical scrubs) in the same routine.
  - Never combine Benzoyl Peroxide with Retinoids or pure L-Ascorbic Acid in the same session due to oxidation and severe irritation.
  - Separate Retinoids and AHA/BHA onto alternate nights with recovery nights in between.
  - Pair Copper Peptides (GHK-Cu) away from low-pH acids and pure L-Ascorbic Acid.
- **Layering Order:** Apply from thinnest/lowest-pH to thickest/most occlusive: Cleanser -> Watery Toner/Essence -> Low-pH Active (wait 1-3 min if needed) -> Hydrating/Soothing Serum -> Eye Cream -> Moisturizer/Barrier Cream -> Facial Oil (PM) or Sunscreen (AM).

### Step 3: Structure Phased Progression and Cycling

Consult `references/phased-routine-templates.md` to select the right cadence instead of a flat daily list:

- **Phase 0 (SOS Barrier Repair, 7-14 days):** Trigger whenever skin stings with basic moisturizer, flushes easily, or peels. Strip all acids, retinoids, and high-dose vitamin C. Use only gentle non-foaming cleanser, humectants (hyaluronic acid, panthenol, ectoin), barrier lipids (ceramides, cholesterol, fatty acids, squalane), and SPF.
- **Phase 1 (Tolerance Ramp-Up, Weeks 2-4):** Introduce one primary active at low frequency (e.g., 1-2 nights/week) using the sandwich method (moisturizer -> active -> moisturizer) if needed.
- **Phase 2 (Targeted Skin Cycling, Weeks 4-12):** Use a structured 4-night, 5-night, or 6-night rotation (e.g., Night 1 Exfoliation -> Night 2 Retinoid -> Nights 3-4+ Barrier Recovery). Extend recovery nights for sensitive skin or dry climates.
- **Phase 3 (Long-Term Maintenance):** Stabilize sustainable weekly frequency, specify seasonal swaps (lighter gel-creams in humid weather, richer ceramide creams in dry weather), and define clear pause/resume triggers.

### Step 4: Deliver Dual-Format Actionable Output and Validate

Present the plan in a crisp, scannable structure without filler:

1. **Executive Diagnosis and Strategy Summary (3-5 bullets):** Skin state assessment, core active strategy, and key adjustments made from previous versions or logs.
2. **Product Role Mapping Table:** Map each owned product to its exact role, active ingredient, and allowed time slot (AM / PM-Active / PM-Recovery / Pause).
3. **Phased Weekly or Cycle Calendar:** Day-by-day AM and PM step-by-step execution table with exact product names, amounts (e.g., pea-sized), and application notes.
4. **Dynamic Adjustment Rules (If-Then Guardrails):** Explicit rules for when to add a recovery night (e.g., tightness or stinging upon applying plain moisturizer) vs. how to distinguish normal mild retinoid purging from barrier irritation.
5. **Structured Calendar Payload (when requested or for app integration):** Output a clean JSON schedule matching the schema in `references/phased-routine-templates.md`, then validate the JSON using `scripts/validate_plan.py` (or run its rules) to verify zero ingredient conflicts, valid product IDs, and schema completeness before returning it to the user.

## Gotchas

- **Do not recommend buying new products by default:** Users with existing skincare collections want their current inventory organized safely first. Only suggest filling a genuine functional gap (such as missing daily sunscreen or a basic ceramide moisturizer for recovery nights), and mark it clearly as optional.
- **Do not confuse purging with irritation:** Purging happens only in usual breakout zones with ingredients that accelerate cell turnover (retinoids, AHA/BHA) and resolves within 4-6 weeks. Redness, burning, tightness, or bumps in new areas indicate barrier damage and require immediate reversion to Phase 0 recovery.
- **Avoid vague step names:** Never write "Apply serum" or "Use active." Always specify the exact product name or ingredient class, concentration tier, and order.
- **Always run validation on structured JSON output:** When outputting JSON for calendar apps (`PlanCalendar`), execute `scripts/validate_plan.py` to catch any incompatible active pairings or missing fields before finalizing.
