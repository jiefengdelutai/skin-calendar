#!/usr/bin/env python3
"""
Skincare Plan Markdown & Safety Validator (for AI护肤手册 / skin-calendar)

Validates AI-generated Markdown skincare plans before importing into the React app
or Xiaohongshu mini-tool:
1. Extracts the 5-column Markdown calendar table matching /^\|?\s*\d{4}-\d{2}-\d{2}\s*\|/
2. Verifies exact 5-column structure: 日期 | 星期 | 早上怎么用 | 晚上怎么用 | 当日提醒
3. Verifies valid YYYY-MM-DD dates, chronological continuity (no skipped days), and accurate weekdays
4. Ensures every AM/PM cell is self-contained (rejects lazy placeholders like "同上" / "同周一")
5. Enforces hard active-ingredient & post-procedure conflict rules within each AM/PM cell
   and warns on consecutive-night potent active stacking.
"""

import datetime
import json
import re
import sys
from pathlib import Path

WEEKDAY_MAP = ["周一", "周二", "周三", "周四", "周五", "周六", "周日"]

LAZY_PLACEHOLDERS = [
    "同上", "同前", "同周一", "同周二", "同周三", "同周四", "同周五", "同周六", "同周日",
    "按基础流程", "按早间流程", "按晚间流程", "见上表", "略"
]

RETINOID_TERMS = ["a醇", "视黄醇", "视黄醛", "维a", "阿达帕林", "tretinoin", "retinol", "retinal", "adapalene"]
EXFOLIANT_TERMS = ["水杨酸", "果酸", "甘醇酸", "乳酸", "杏仁酸", "壬二酸", "刷酸", "去角质", "磨砂", "aha", "bha", "pha", "salicylic", "glycolic"]
BPO_TERMS = ["过氧化苯甲酰", "班赛", "benzoyl peroxide", "bpo"]
PURE_VITC_TERMS = ["原型vc", "左旋维c", "l-ascorbic", "pure vitamin c"]
COPPER_PEPTIDE_TERMS = ["蓝铜胜肽", "copper peptide", "ghk-cu"]
MEDICAL_DRESSING_TERMS = ["肤创宁", "医用敷料", "生长因子"]
COSMETIC_MASK_TERMS = ["面膜", "色修面膜", "湿敷"]


def contains_any(text: str, terms: list[str]) -> list[str]:
    low = text.lower()
    return [t for t in terms if t in low]


def validate_markdown_plan(md_text: str) -> dict:
    errors = []
    warnings = []

    lines = md_text.splitlines()
    row_pattern = re.compile(r"^\|?\s*(\d{4}-\d{2}-\d{2})\s*\|")

    parsed_rows = []
    for line_no, raw_line in enumerate(lines, start=1):
        if row_pattern.match(raw_line.strip()):
            stripped = raw_line.strip()
            if stripped.startswith("|"):
                stripped = stripped[1:]
            if stripped.endswith("|"):
                stripped = stripped[:-1]
            cells = [c.strip() for c in stripped.split("|")]
            parsed_rows.append((line_no, cells))

    if not parsed_rows:
        errors.append("No calendar rows matching '| YYYY-MM-DD | ... |' were found. App PlanCalendar will fail to render.")
        return {"valid": False, "row_count": 0, "errors": errors, "warnings": warnings}

    prev_date = None
    prev_pm_potent = False

    for idx, (line_no, cells) in enumerate(parsed_rows):
        if len(cells) != 5:
            errors.append(
                f"Line {line_no}: Expected exactly 5 columns (日期|星期|早上怎么用|晚上怎么用|当日提醒), got {len(cells)}."
            )
            continue

        date_str, weekday_str, am_text, pm_text, reminder_text = cells

        # 1. Validate date & weekday accuracy
        try:
            dt = datetime.date.fromisoformat(date_str)
            expected_wd = WEEKDAY_MAP[dt.weekday()]
            if weekday_str != expected_wd:
                errors.append(
                    f"Line {line_no} ({date_str}): Weekday mismatch — got '{weekday_str}', expected '{expected_wd}'."
                )
            if prev_date is not None:
                delta = (dt - prev_date).days
                if delta != 1:
                    warnings.append(
                        f"Line {line_no} ({date_str}): Non-consecutive date jump from {prev_date.isoformat()} (delta={delta} days)."
                    )
            prev_date = dt
        except ValueError:
            errors.append(f"Line {line_no}: Invalid ISO date '{date_str}'.")

        # 2. Check self-contained AM/PM instructions
        for period_label, cell_text in [("AM", am_text), ("PM", pm_text)]:
            if len(cell_text) < 6:
                errors.append(f"Line {line_no} ({date_str}) [{period_label}]: Step text too short ('{cell_text}').")
            for lazy in LAZY_PLACEHOLDERS:
                if cell_text == lazy or (len(cell_text) <= 12 and lazy in cell_text):
                    errors.append(
                        f"Line {line_no} ({date_str}) [{period_label}]: Contains shorthand placeholder '{cell_text}'. Each day must be self-contained."
                    )

        # 3. Check hard active & medical conflicts per session
        for period_label, cell_text in [("AM", am_text), ("PM", pm_text)]:
            has_ret = contains_any(cell_text, RETINOID_TERMS)
            has_exf = contains_any(cell_text, EXFOLIANT_TERMS)
            has_bpo = contains_any(cell_text, BPO_TERMS)
            has_vc = contains_any(cell_text, PURE_VITC_TERMS)
            has_cu = contains_any(cell_text, COPPER_PEPTIDE_TERMS)
            has_med = contains_any(cell_text, MEDICAL_DRESSING_TERMS)
            has_mask = contains_any(cell_text, COSMETIC_MASK_TERMS)

            if has_ret and has_exf:
                errors.append(
                    f"Line {line_no} ({date_str}) [{period_label}]: CRITICAL CONFLICT — Retinoid ({has_ret[0]}) and exfoliant/acid ({has_exf[0]}) stacked in the same session."
                )
            if has_ret and has_bpo:
                errors.append(
                    f"Line {line_no} ({date_str}) [{period_label}]: CRITICAL CONFLICT — Retinoid ({has_ret[0]}) and Benzoyl Peroxide ({has_bpo[0]}) stacked."
                )
            if has_cu and (has_exf or has_vc):
                errors.append(
                    f"Line {line_no} ({date_str}) [{period_label}]: CRITICAL CONFLICT — Copper Peptides ({has_cu[0]}) combined with low-pH acid/Vit C."
                )
            if has_med and (has_mask or has_exf or has_ret):
                errors.append(
                    f"Line {line_no} ({date_str}) [{period_label}]: CRITICAL CONFLICT — Medical wound dressing ({has_med[0]}) combined with cosmetic mask or active."
                )

            # Check if two distinct brightening/spot serums are stacked in one night
            if ("科颜氏" in cell_text and "淡斑" in cell_text) and ("倩碧" in cell_text and "302" in cell_text):
                errors.append(
                    f"Line {line_no} ({date_str}) [{period_label}]: Two brightening serums (科颜氏淡斑 + 倩碧302) stacked in one session; split onto separate nights."
                )

            if period_label == "PM":
                pm_potent = bool(has_ret or has_exf)
                if pm_potent and prev_pm_potent:
                    warnings.append(
                        f"Line {line_no} ({date_str}) [PM]: Potent actives scheduled on consecutive nights without a recovery buffer."
                    )
                prev_pm_potent = pm_potent

    return {
        "valid": len(errors) == 0,
        "row_count": len(parsed_rows),
        "date_range": f"{parsed_rows[0][1][0]} to {parsed_rows[-1][1][0]}" if len(parsed_rows[0][1]) >= 1 else "unknown",
        "errors": errors,
        "warnings": warnings,
    }


def main():
    if len(sys.argv) < 2:
        print("Usage: python validate_plan.py <path_to_plan.md>")
        sys.exit(1)

    path = Path(sys.argv[1])
    if not path.exists():
        print(f"File not found: {path}")
        sys.exit(1)

    md_text = path.read_text(encoding="utf-8")
    result = validate_markdown_plan(md_text)
    print(json.dumps(result, ensure_ascii=False, indent=2))
    sys.exit(0 if result["valid"] else 1)


if __name__ == "__main__":
    main()
