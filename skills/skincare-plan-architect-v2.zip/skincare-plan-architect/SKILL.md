---
name: skincare-plan-architect
description: Design, audit, and optimize personalized, science-backed skincare routines, phased skin recovery schedules, and long-term maintenance calendars for the AI Skincare Manual (AI护肤手册 / skin-calendar) app and mini-tool. Use whenever the user asks to generate or improve a skincare plan, audit or rewrite a skincare prompt template, resolve active ingredient conflicts, build a phased recovery or skin cycling schedule, adjust a routine based on exported execution logs (护肤记录.json / 护理效果记录), or validate Markdown calendar tables for import into PlanCalendar.
---

# Skincare Plan Architect

Generate precision, executable skincare plans tailored to the **AI Skincare Manual (`AI护肤手册` / `skin-calendar`)** workflow: eliminate generic AI fluff, enforce product verification and zone-based safety, prevent active ingredient overload, and output a valid 5-column Markdown calendar (`日期 | 星期 | 早上怎么用 | 晚上怎么用 | 当日提醒`) that imports directly into the app without manual editing.

## Core Principles (Learned from Real Iteration & Clinical Guardrails)

1. **Zero Fabrication & Version-Specific Verification:** Verify official brand product usage, active forms, rinse/leave-on rules, and expiration/PAO limits. If a product link cannot be opened or regional formulations differ (e.g., CN vs. US/UK versions), explicitly mark unverified concentrations or rules as `未确认` and use conservative baseline frequency rather than guessing. Never treat social media anecdotes (such as Xiaohongshu posts) as clinical proof of concentration or wound healing.
2. **Zone-Based & Condition-Gated Execution:** Never apply a blanket full-face routine when the user has recent laser/aesthetic treatment zones, broken skin, or localized sensitivity. Separate **treated/compromised zones** from **intact, non-treated zones**, and define explicit daily **Go/No-Go execution conditions** (e.g., intact surface, zero exudate, zero stinging with plain moisturizer) that automatically defer new actives when unmet.
3. **Strict Anti-Stacking & Barrier-First Phasing:** Barrier repair always overrides cosmetic brightening or acne actives. Introduce or re-introduce only one product at a time on a small intact test patch, spaced at least 48 hours apart, before expanding coverage or rotating actives.
4. **Native App Compatibility (`skin-calendar`):** Always output the exact 5-column Markdown table (`| 日期 | 星期 | 早上怎么用 | 晚上怎么用 | 当日提醒 |`) with `YYYY-MM-DD` dates, self-contained daily instructions (never just writing "same as Monday"), and validate the generated Markdown with `scripts/validate_plan.py` before delivering it.

## When to Use

- Generating a new personalized, phased skincare plan (post-laser/procedure recovery, barrier repair, acne/PIH control, anti-aging, or brightening).
- Reviewing and upgrading the built-in prompt template in `src/main.jsx`, `src/PromptForm.jsx`, or `prompt.txt`.
- Auditing an exported execution record (`护肤记录.json` / `护理效果记录.txt`) containing daily completion flags, skin reaction notes, and treatment logs to generate the next phase's adjusted calendar.
- Validating any AI-generated Markdown skincare plan before importing it into the web app or Xiaohongshu mini-tool.

## Workflow

### Step 1: Audit User Profile, Medical Context, and Product Inventory

Extract and lock down five inputs from the user's form output, attached files, or exported JSON logs:

1. **Medical & Treatment Timeline (Highest Priority):** Check for recent aesthetic/laser treatments, exact procedure dates, scabbing/healing status, prescribed topicals (e.g., medical dressings/sprays), and physician instructions (such as water-avoidance windows or strict sun avoidance). Never mix cosmetic masks or actives with prescribed wound dressings.
2. **Current Skin State vs. Ranked Goals:** Separate immediate barrier symptoms (stinging, itching, redness, peeling, tightness) from ranked cosmetic goals (1. stability/healing, 2. acne prevention, 3. post-inflammatory hyperpigmentation/red marks, 4. overall tone).
3. **Owned Product Inventory & Packaging Constraints:** Catalog every owned product with exact name, volume, regional version, expiration/PAO status, texture, and past tolerance history. Prioritize organizing owned products; never push new purchases unless a critical safety step (such as broad-spectrum sunscreen) is missing.
4. **Routine & Time Constraints:** Respect AM/PM time budgets (e.g., water-only rinse in AM, <=5 minutes in PM) and physical sun-protection habits (UV mask/facekini, hat, parasol).
5. **Historical Execution Logs (`records`):** If the user provides `护肤记录.json`, inspect daily completion rates, reaction notes (`早间说明` / `晚间说明` / `当天其他情况`), and which products were already tolerated vs. paused.

If critical safety data (such as active wound status or unknown product versions) is missing, ask targeted clarifying questions first while providing safe baseline care.

### Step 2: Enforce Formulation, Compatibility, and Zone Guardrails

Consult `references/ingredient-compatibility-matrix.md` to verify every AM, PM, and weekly slot:

- **AM = Minimalist Protection:** Lukewarm water rinse (or gentle cleanser only if visibly oily) -> tolerated barrier moisturizer on dry zones -> broad-spectrum SPF 30-50+ on healed exposed skin + physical UV protection (avoiding friction on treated spots).
- **PM = Single-Focus Rotation:** Never stack multiple potent actives (e.g., two brightening/exfoliating serums, or spot acne lotion + acid/retinoid) in the same night during recovery or sensitivity phases.
- **Hard Conflict Prevention:**
  - Never stack two chemical/physical exfoliants (AHA, BHA, PHA, scrubs) in one session.
  - Never combine Benzoyl Peroxide with Retinoids or pure L-Ascorbic Acid in the same session.
  - Separate Retinoids and AHA/BHA onto alternate nights with recovery nights in between.
  - Keep Copper Peptides (GHK-Cu) separate from low-pH acids and pure L-Ascorbic Acid.
  - Never layer cosmetic sheet/wash-off masks over medical wound sprays/dressings.
- **Layering Order (Thin to Thick / Low pH to High pH):** Cleanser -> Watery Toner (optional, skip on active nights during ramp-up) -> Targeted Serum (leave-on) or Wash-Off Mask (10-15 min, rinse) -> Barrier Moisturizer (Ceramides/Cholesterol/Fatty Acids) -> Sunscreen (AM).

### Step 3: Build Phased Progression & Conditional Adjustment Rules

Consult `references/phased-routine-templates.md` to structure the timeline across phases:

- **Phase 0 (Post-Procedure / SOS Barrier Stabilization):** Strict adherence to medical orders; gentle cleanse + tolerated barrier cream + physical/broad-spectrum sun protection only. Zero acids, zero retinoids, zero masks, zero brightening actives.
- **Phase 1 (Single-Product Patch & Tolerance Ramp-Up):** Introduce one tolerated or low-irritation product at a time on intact, non-treated skin first, spaced 48+ hours apart. Define exact exit criteria before touching healed treatment edges.
- **Phase 2 (Alternating Rotation / Customized Skin Cycling):** Rotate distinct functional nights (e.g., Brightening Night A -> Barrier Recovery Night -> Soothing/Hydrating Night -> Brightening Night B -> Recovery Night) with explicit substitution rules (e.g., acne spot lotion replaces a brightening night rather than stacking on top).
- **Phase 3 (Long-Term Maintenance & Expiry Management):** Set sustainable weekly frequencies, prioritize products nearing expiration/PAO without over-applying, and define clear pause/medical-referral triggers.

### Step 4: Generate App-Ready Markdown & Validate with Script

Structure the final response in the exact sequence expected by the user and the `AI护肤手册` executor:

1. **Basis & Safety Gates (本次方案依据与统一执行条件):** Summarize key adjustments from prior plans/logs, list verified product roles with source links and `未确认` flags, and state the daily Go/No-Go condition.
2. **Product Role, Dosage & Layering Reference Table:** Exact starting amounts (drops/pumps/pea-sized), target zones (full face vs. non-treated intact skin vs. acne-prone zones only), rinse/leave-on rules, and expiry/PAO checks.
3. **Fixed AM Routine & Named PM Workflows (每日早晚流程):** Clear AM steps plus named PM templates (e.g., `基础晚`, `舒缓晚`, `功效晚A`, `功效晚B`, `面膜晚`, `祛痘替换晚`).
4. **Phased Progression & Weekly Maintenance Table (阶段推进与周一至周日安排):** How frequencies evolve from current recovery to steady-state weekly rotation, plus clear If-Then adjustment rules.
5. **Complete Day-by-Day Markdown Calendar (逐日护肤日历):**
   - Must use the exact 5-column Markdown header: `| 日期 | 星期 | 早上怎么用 | 晚上怎么用 | 当日提醒 |`
   - Date format must be `YYYY-MM-DD`, matching accurate weekdays (`周一` to `周日`).
   - Every row must contain complete, self-contained instructions (never write only "同周一" or "按基础流程" without specifics) so the app's single-day card view displays full actionable steps.
6. **Automated Validation:** Run `scripts/validate_plan.py` against the generated `.md` file to verify table syntax, date continuity, weekday accuracy, self-contained cell completeness, and active conflict guardrails before returning the plan.

## Gotchas

- **Do not output JSON when the user wants to import into `AI护肤手册`:** The React web app (`src/main.jsx`) and Xiaohongshu mini-tool (`minitool/source/main.jsx`) parse Markdown tables matching `/^\|?\s*\d{4}-\d{2}-\d{2}\s*\|/`. Always deliver the complete Markdown document with the 5-column table as the primary artifact.
- **Do not apply actives to healing laser zones prematurely:** Even after scabs fall off, new pink epidermis requires barrier stabilization first. Keep actives on intact non-treated skin first, then test one small healed edge with a 48-hour observation window.
- **Do not confuse purging with irritation:** Purging occurs only in habitual breakout zones from cell-turnover actives (retinoids, AHA/BHA) and resolves in 4-6 weeks. Itching, stinging with plain moisturizer, diffuse redness, or bumps in new areas indicate irritation and require immediate fallback to `基础晚`.
