# Active Ingredient Compatibility, Zone Safety & Layering Matrix

Use this reference when auditing product combinations, verifying regional product versions, and ordering AM/PM steps.

## 1. Ingredient & Product Pairing Matrix

| Pairing | Verdict | Mechanism and Execution Rule |
| :--- | :--- | :--- |
| **Activated C / Vit C Derivatives + Ceramide Barrier Cream** | Synergistic | Gentle antioxidant brightening paired with ceramides/cholesterol/fatty acids minimizes irritation during post-redness recovery. |
| **Pure L-Ascorbic Acid + Sunscreen** | Highly Recommended (AM) | Neutralizes UV-induced free radicals under broad-spectrum SPF 30-50+. Split from PM retinoids. |
| **Retinoid + Niacinamide** | Synergistic | Niacinamide supports barrier ceramide synthesis and reduces retinoid dryness. |
| **Retinoid + AHA / BHA** | Separate Nights | Cumulative barrier disruption risk. Alternate nights with at least 1-2 recovery nights between them. |
| **Retinoid + Benzoyl Peroxide** | Do Not Mix | BPO oxidizes traditional retinoids and causes severe irritation. Use on separate days or AM short-contact wash. |
| **Two Brightening / Exfoliating Serums (e.g., Dark Spot Serum A + Serum B)** | Alternate Nights | Even without direct chemical incompatibility, stacking two multi-active serums in recovery/sensitive skin increases cumulative irritation and obscures which product caused a reaction. |
| **BHA / Acne Treatment Lotion + Exfoliating Acids / Brightening Actives** | Replace, Do Not Stack | Use acne treatment lotion on dedicated nights in acne-prone zones only; omit other actives and wash-off masks that night. |
| **Copper Peptides (GHK-Cu) + Low-pH Acids / Pure Vit C** | Separate | Low pH destabilizes copper peptide complexes. Keep on separate nights or AM/PM split. |
| **Medical Wound Dressing / Spray + Cosmetic Masks or Actives** | Strict Separation | Never layer cosmetic sheet/gel masks or active serums over prescribed post-laser wound sprays or dressings. |

## 2. Standard Layering Order & Zone Rules

### Morning (AM) Routine Order

1. **Cleanse:** Lukewarm water rinse (use gentle amino-acid cleanser only if visibly oily). Avoid rubbing healing or post-laser zones.
2. **Barrier Moisturizer:** Thin layer of ceramide/cholesterol/fatty acid cream (e.g., 242), adjusted by facial zone (more on dry cheeks, minimal on oily T-zone).
3. **Broad-Spectrum Sunscreen (SPF 30-50+, PA++++):** Apply on intact, fully healed skin 15 minutes before sun exposure. Pair with physical protection (UV mask/facekini, wide-brim hat, parasol) without seam friction on healing spots.

### Evening (PM) Routine Order

1. **Cleanse:** Gentle pH-balanced amino-acid cleanser (20-30s light massage on intact skin, rinse thoroughly, pat dry with clean towel). Remove water-resistant SPF/makeup gently without double-washing with harsh cleanser.
2. **Optional Hydrating/Soothing Toner (Recovery Nights Only during Ramp-Up):** Thin palm press on tolerated intact skin; skip on active nights initially to minimize penetration spikes and isolate reactions.
3. **Single Targeted Step (Active / Mask Nights Only):**
   - *Brightening / Antioxidant Serum Night:* 2-3 drops or 1 pump on dry, intact skin; leave on.
   - *Soothing Serum Night:* 2-3 drops on dry, intact skin; leave on.
   - *Wash-Off Soothing Mask Night:* Thin even layer for 10-15 minutes, rinse with cool-to-lukewarm water, pat dry. Omit other serums that night.
   - *Acne Spot/Zone Lotion Night:* Thin layer strictly on intact, non-treated acne-prone zones; leave on. Omit brightening serums, toners, and masks.
4. **Barrier Moisturizer Seal:** Ceramide/cholesterol/fatty acid cream over the face to lock in hydration.

## 3. Purging vs. Barrier Irritation vs. Post-Procedure Warning Signs

| Dimension | Normal Turnover Purging | Barrier Irritation / Allergic Reaction | Medical Referral Triggers (Post-Procedure) |
| :--- | :--- | :--- | :--- |
| **Trigger** | Cell-turnover actives (retinoids, AHA/BHA) only. | Over-exfoliation, fragrance/botanical sensitivity, or stacking actives too fast. | Infection, delayed wound healing, or contact dermatitis on treated sites. |
| **Symptoms** | Small whiteheads/blackheads surfacing in usual clogged zones without burning. | Stinging/itching when applying plain water or basic ceramide cream, diffuse redness, tightness, new bumps in unusual areas. | Worsening pain, heat, swelling, pus/exudate, bleeding, or expanding erythema on laser-treated spots. |
| **Action** | Maintain low frequency; do not squeeze or layer extra spot acids. | Stop all actives immediately; revert to `基础晚` (gentle cleanse + tolerated barrier cream) until comfortable for 5+ days. | Stop all cosmetics on the area immediately and consult the treating dermatologist/clinic. |
