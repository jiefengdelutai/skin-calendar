# Phased Progression Templates & App Calendar Spec

Use these templates to design multi-week plans compatible with the **AI Skincare Manual (`AI护肤手册`)** Markdown parser.

## 1. Phased Progression Cadence

### Phase 0: Post-Procedure / SOS Barrier Repair (7 to 14+ Days)

- **Trigger:** Active post-laser healing, scabbing, recent peeling, or stinging with plain moisturizer.
- **Rules:** Zero acids, zero retinoids, zero brightening serums, zero wash-off masks. Follow medical wound-care orders strictly.
- **AM:** Water rinse -> Tolerated barrier moisturizer -> Physical UV protection (+ broad-spectrum SPF on healed intact skin).
- **PM:** Gentle amino-acid cleanse -> Tolerated barrier moisturizer (plus prescribed topical on treatment zones only if within medical course).

### Phase 1: Single-Product Tolerance Ramp-Up (Weeks 2 to 4)

- **Trigger:** Scabs naturally shed, surface completely closed without exudate, plain water and barrier cream feel comfortable for 5+ consecutive days.
- **Rules:**
  - Introduce **one** product at a time on intact, **non-treated** skin first.
  - Space newly introduced products by at least **48 hours** to isolate delayed irritation.
  - Test any active on a single healed treatment edge only after non-treated skin tolerates 2+ applications without redness or itching.

### Phase 2: Customized Alternating Rotation (Weeks 4 to 8+)

- **Pattern (7-Day Steady-State Rotation):**
  - **Mon:** Brightening Serum A (Leave-on) -> Barrier Cream
  - **Tue:** Soothing Serum (Optional) -> Barrier Cream
  - **Wed:** Brightening Serum B (Leave-on) -> Barrier Cream
  - **Thu:** Soothing Toner (Optional) -> Barrier Cream
  - **Fri:** Brightening Serum A (or replaced by Acne Zone Lotion if breakouts persist) -> Barrier Cream
  - **Sat:** Wash-Off Soothing Mask (10-15 min, rinse) -> Barrier Cream
  - **Sun:** Brightening Serum B -> Barrier Cream

### Phase 3: Long-Term Maintenance & Expiry Management

- Check product expiration (`EXP`) and Period-After-Opening (`PAO`) dates before scheduling; never increase thickness or frequency just to finish a nearing-expiry bottle.
- If increasing frequency after 4+ weeks of zero irritation, adjust only one product by +1 night/week and observe for 14 days.

## 2. Native App Markdown Table Specification (`PlanCalendar` Parser)

The React web app (`src/main.jsx`) and Xiaohongshu mini-tool (`minitool/source/main.jsx`) extract calendar rows using:
`/^\|?\s*\d{4}-\d{2}-\d{2}\s*\|/` and split columns by `|`.

### Required Table Structure

```markdown
| 日期 | 星期 | 早上怎么用 | 晚上怎么用 | 当日提醒 |
|---|---|---|---|---|
| 2026-11-25 | 周三 | 清水轻洗→修丽可242按需薄涂→已长好的外露皮肤涂已耐受防晒霜，配合不摩擦治疗区的脸基尼、帽伞。 | 欧莱雅氨基酸洗面奶轻洗并冲净→轻按干→修丽可242薄涂，留到次晨。 | 开始记录：同一光线拍正面及两侧，记录痒、刺、脱皮。今天不增加产品。 |
```

### Mandatory Formatting Rules for App Rendering

1. **Exact 5 Columns:** `日期` | `星期` | `早上怎么用` | `晚上怎么用` | `当日提醒`.
2. **ISO Date Format:** `YYYY-MM-DD` (zero-padded month and day) with matching Chinese weekday (`周一`..`周日`).
3. **Self-Contained Cells:** Because the mobile UI renders only the selected day's AM and PM cells on screen, **every cell must spell out the full step sequence** (e.g., `洁面→精华→面霜`), never shorthand like `同上` or `按周表执行`.
4. **Explicit Zone & Fallback Notes:** State whether actives apply only to `未治疗的完整皮肤` or `已耐受区域`, and include a clear fallback reminder when testing a new step.
